LAG BOOST  (Android app)
========================

Yeh asli Android app ka source code hai. App ke andar poori Lag Boost web app chalti hai
(app/src/main/assets/index.html) aur Android ki asli taqat is par "bridge" se judi hai.

Isme:
- VISUAL tab: color grading (7 presets + 7 sliders, hold-to-compare), game ke upar color tint/dim
- PUBG graphics profile: aapki Active.sav se li hui graphics values (FPS, quality, style).
  Backup -> Apply -> Restore. Sirf graphics values likhi jati hain. Account ID, sensitivity aur chat text
  copy NAHI hote (original Active.sav is zip mein shamil nahi hai, us mein account ID thi).
- Awaaz: car intro mein engine + horn, boost par sweep + chime, button clicks, volume control
- Speed Test (asli), Gaming HUD (full screen FPS/ping/battery), boost streak
- Car intro, 6 live wallpaper scenes (har 5 second mein naye rang), iPad view (ek tap mein)
- Phone ki installed games ki list (PUBG, BGMI, Free Fire, COD wagaira khud mil jati hain)
- PLAY: Wi-Fi low-latency lock + tick kiye hue apps band + FPS counter + game start
- Asli ping, jitter, graph, Server Finder, DNS booster, Lag Killer
- Background apps ki list: tick karke KILL NOW, RAM ka asli hisaab
- Game ke upar floating FPS + ping counter (Shizuku ke saath asli GAME FPS)

APK BANANE KE 2 TAREEQE
-----------------------
A) PC par Android Studio (sabse aasan)
   1. Android Studio install karein (Koala ya naya).
   2. File > Open > is folder (LagBoostApp) ko chunein. Gradle sync hone dein.
   3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   4. APK milegi: app/build/outputs/apk/debug/app-debug.apk
   5. Isay phone mein bhej kar install karein ("Unknown sources" allow karna hoga).
   Agar "Gradle" ka error aaye: Settings > Build > Gradle > Gradle JDK = 17.

B) Sirf mobile / bina PC (GitHub se)
   1. github.com par free account banayein, naya repository banayein.
   2. Is poore folder ki files upload karein (.github folder samet).
   3. Repository ke "Actions" tab mein "Build APK" chalayein (Run workflow).
   4. 5-10 minute baad run ke andar "LagBoost-apk" download karein, zip kholein, APK install karein.

PERMISSIONS (pehli baar)
------------------------
- "Display over other apps": FPS counter game ke upar dikhane ke liye.
- Notifications: counter ki notification ke liye.

ASLI GAME FPS KE LIYE: SHIZUKU
------------------------------
Android ek app ko doosre app ka FPS padhne nahi deta. Shizuku (free app) yeh ijazat deta hai.
1. Shizuku install karein (Play Store ya GitHub).
2. Developer options > Wireless debugging ON.
3. Shizuku mein "Start via Wireless debugging".
4. Lag Boost > FPS tab > GRANT SHIZUKU ACCESS.
5. Games tab se BOOST & PLAY dabayein. Counter par "GAME xx FPS" aayega.
Shizuku ke bagair counter "SCREEN xx FPS" dikhata hai (screen kitni smooth chal rahi hai).
Shizuku ke saath background apps ka full force-stop bhi hota hai.

SACH
----
- Koi app ping ko jaadu se kam nahi kar sakta. Yeh app Wi-Fi low-latency lock lagati hai,
  bekar apps band karti hai, aur batati hai ke kya theek karna hai.
- Yeh Android code mere paas compile karke test nahi hua (yahan Android tools nahi the).
  Web wala hissa (index.html) browser mein test ho chuka hai.
  Agar build mein error aaye to error ka text bhej dein, theek kar dunga.
- PUBG ke apne server ke IP public nahi hain. Ping target mein Cloudflare/Google se nateeja milta hai,
  ya aap game ke server ka IP khud daal sakte hain.


VISUAL TAB AUR ACTIVE.SAV (naya)
--------------------------------
1. Shizuku chalu karein (upar ke steps) aur Lag Boost ko access dein.
2. PUBG/BGMI ek baar khol kar band kar dein, taake Active.sav ban jaye.
3. Lag Boost > Visual > "Read my current values" dabayein, phir Backup, phir Apply (do baar tap).
4. Game kholein aur Settings > Graphics mein check karein. Galat lage to Restore dabayein.
Rasta: /sdcard/Android/data/<game package>/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav
Backup usi folder mein Active.sav.lagboost.bak naam se rehta hai (pehla backup kabhi overwrite nahi hota).
Style ke numbers (Classic=1, Colorful=2, Realistic=3, Soft=4, Movie=5) mera andaza hain. Check karke batayein.
Warning: game files badalna game company ki nazar mein tampering ho sakta hai. Account ka risk aap ka hai.
Tint sirf warm/cool/dim kar sakta hai, game ka asli contrast ya saturation nahi badha sakta.
