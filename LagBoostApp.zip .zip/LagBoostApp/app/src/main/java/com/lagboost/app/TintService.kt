@file:Suppress("DEPRECATION")

package com.lagboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout

/**
 * A see-through colored layer over the whole screen (and over your game).
 * It can warm, cool or dim the picture. It cannot raise contrast or saturation.
 */
class TintService : Service() {

    companion object {
        @Volatile var running = false

        fun start(ctx: Context, warm: Int, dim: Int) {
            Prefs.setStr(ctx, "tintWarm", warm.toString())
            Prefs.setStr(ctx, "tintDim", dim.toString())
            val i = Intent(ctx, TintService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TintService::class.java))
        }
    }

    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var tintV: View? = null
    private var dimV: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("lagboost_tint", "Lag Boost screen tint", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, "lagboost_tint")
            .setContentTitle("Lag Boost screen tint is on")
            .setContentText("Color filter over your screen. Turn it off inside the app.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (root == null) addViews()
        val warm = Prefs.getStr(this, "tintWarm", "0").toIntOrNull() ?: 0
        val dim = Prefs.getStr(this, "tintDim", "0").toIntOrNull() ?: 0
        paint(warm, dim)
        running = true
        return START_STICKY
    }

    private fun addViews() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val fl = FrameLayout(this)
        val t = View(this)
        val d = View(this)
        fl.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        fl.addView(d, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm?.addView(fl, lp)
        root = fl
        tintV = t
        dimV = d
    }

    private fun paint(warm: Int, dim: Int) {
        val a = (Math.abs(warm) * 1.6f).toInt().coerceIn(0, 160)
        tintV?.setBackgroundColor(if (warm >= 0) Color.argb(a, 255, 140, 30) else Color.argb(a, 40, 120, 255))
        val da = (dim.coerceIn(0, 70) * 2.55f * 0.7f).toInt()
        dimV?.setBackgroundColor(Color.argb(da, 0, 0, 0))
    }

    override fun onDestroy() {
        running = false
        try {
            if (root != null) wm?.removeView(root)
        } catch (e: Exception) {
        }
        root = null
        tintV = null
        dimV = null
        super.onDestroy()
    }
}
