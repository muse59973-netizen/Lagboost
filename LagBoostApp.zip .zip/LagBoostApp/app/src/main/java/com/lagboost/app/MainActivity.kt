@file:Suppress("DEPRECATION")

package com.lagboost.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

/**
 * Shows the full Lag Boost web app (car intro, live wallpaper, iPad view, tools)
 * and gives it real phone powers through the "Android" bridge.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var cache: List<AppItem> = emptyList()
    private var cacheTime = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#05070D")
        window.navigationBarColor = Color.parseColor("#05070D")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#05070D"))
        val ws = web.settings
        ws.javaScriptEnabled = true
        ws.domStorageEnabled = true
        ws.allowFileAccess = true
        ws.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val sc = u.scheme
                if (sc == "http" || sc == "https") {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                    return true
                }
                return false
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------ helpers

    private fun loadApps(): List<AppItem> {
        val now = System.currentTimeMillis()
        if (cache.isEmpty() || now - cacheTime > 5000L) {
            cache = Apps.load(this)
            cacheTime = now
        }
        return cache
    }

    private fun appsJson(gamesOnly: Boolean): String {
        val arr = JSONArray()
        for (a in loadApps()) {
            if (a.isSystem) continue
            if (gamesOnly && !a.isGame) continue
            val o = JSONObject()
            o.put("name", a.label)
            o.put("pkg", a.pkg)
            arr.put(o)
        }
        return arr.toString()
    }

    private fun parseList(json: String): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(json)
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun killList(list: List<String>, keep: String): Int {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val targets = ArrayList<String>()
        for (p in list) if (p != keep && p != packageName) targets.add(p)
        for (p in targets) {
            try {
                am.killBackgroundProcesses(p)
            } catch (e: Exception) {
            }
        }
        if (Shell.granted() && targets.isNotEmpty()) {
            val t = Thread {
                for (p in targets) Shell.run("am force-stop $p")
            }
            t.start()
        }
        return targets.size
    }

    private fun openOverlaySettings() {
        runOnUiThread {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    // ------------------------------------------------------------ bridge

    inner class Bridge {

        @JavascriptInterface
        fun isNative(): Boolean = true

        @JavascriptInterface
        fun getGames(): String = appsJson(true)

        @JavascriptInterface
        fun getApps(): String = appsJson(false)

        @JavascriptInterface
        fun ramInfo(): String {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return "{\"free\":" + (mi.availMem / 1048576L) + ",\"total\":" + (mi.totalMem / 1048576L) + "}"
        }

        @JavascriptInterface
        fun kill(json: String): Int = killList(parseList(json), "")

        /** Boost, then start the game. Returns "ok:N", "need_overlay" or "no_launch". */
        @JavascriptInterface
        fun play(pkg: String, killJson: String, overlay: Boolean, lock: Boolean): String {
            val launch = packageManager.getLaunchIntentForPackage(pkg) ?: return "no_launch"
            Prefs.setStr(this@MainActivity, Prefs.TARGET, pkg)
            GameFps.reset()
            PingMonitor.reset()
            PingMonitor.start()
            if (lock) WifiLockHolder.acquire(this@MainActivity)
            val killed = killList(parseList(killJson), pkg)
            if (overlay) {
                if (OverlayService.canDraw(this@MainActivity)) {
                    OverlayService.start(this@MainActivity)
                } else {
                    openOverlaySettings()
                    return "need_overlay"
                }
            }
            runOnUiThread { startActivity(launch) }
            return "ok:$killed"
        }

        /** Turns the floating FPS counter on or off. */
        @JavascriptInterface
        fun overlay(on: Boolean): String {
            if (on) {
                if (OverlayService.canDraw(this@MainActivity)) {
                    OverlayService.start(this@MainActivity)
                    return "ok"
                }
                openOverlaySettings()
                return "need_permission"
            }
            OverlayService.stop(this@MainActivity)
            return "ok"
        }

        @JavascriptInterface
        fun shizuku(): String = if (Shell.granted()) "granted" else if (Shell.alive()) "running" else "off"

        @JavascriptInterface
        fun shizukuRequest() {
            runOnUiThread { Shell.request() }
        }

        /** PUBG settings file: read as base64, backup, write, restore. Needs Shizuku. */
        @JavascriptInterface
        fun savRead(pkg: String): String = SavTools.read(pkg)

        @JavascriptInterface
        fun savBackup(pkg: String): String = SavTools.backup(pkg)

        @JavascriptInterface
        fun savWrite(pkg: String, b64: String): String = SavTools.write(pkg, b64)

        @JavascriptInterface
        fun savRestore(pkg: String): String = SavTools.restore(pkg)

        /** Screen tint over everything (warm or cool) and dim. warm -100..100, dim 0..70. */
        @JavascriptInterface
        fun tint(on: Boolean, warm: Int, dim: Int): String {
            if (!on) {
                TintService.stop(this@MainActivity)
                return "ok"
            }
            if (!OverlayService.canDraw(this@MainActivity)) {
                openOverlaySettings()
                return "need_permission"
            }
            TintService.start(this@MainActivity, warm.coerceIn(-100, 100), dim.coerceIn(0, 70))
            return "ok"
        }

        @JavascriptInterface
        fun keepAwake(on: Boolean) {
            runOnUiThread {
                if (on) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }
    }
}
