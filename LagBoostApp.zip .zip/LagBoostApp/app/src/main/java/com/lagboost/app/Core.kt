@file:Suppress("DEPRECATION")

package com.lagboost.app

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import rikka.shizuku.Shizuku
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/** Saved settings. */
object Prefs {
    private fun sp(c: Context): SharedPreferences = c.getSharedPreferences("lagboost", Context.MODE_PRIVATE)

    fun getBool(c: Context, k: String, def: Boolean): Boolean = sp(c).getBoolean(k, def)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun getStr(c: Context, k: String, def: String): String = sp(c).getString(k, def) ?: def
    fun setStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun getSet(c: Context, k: String): MutableSet<String> = HashSet(sp(c).getStringSet(k, emptySet()) ?: emptySet())
    fun setSet(c: Context, k: String, v: Set<String>) = sp(c).edit().putStringSet(k, HashSet(v)).apply()

    const val KILL_ON_LAUNCH = "killOnLaunch"
    const val OVERLAY_ON_LAUNCH = "overlayOnLaunch"
    const val LOW_LATENCY = "lowLatency"
    const val TARGET = "target"
    const val KILL_SET = "killSet"
    const val PING_HOST = "pingHost"
    const val PING_PORT = "pingPort"
}

/** Real latency: measures how long a TCP connection takes to open, once per second. */
data class PingStats(val last: Int, val avg: Int, val min: Int, val max: Int, val jitter: Int, val loss: Int, val count: Int)

object PingMonitor {
    @Volatile var host: String = "1.1.1.1"
    @Volatile var port: Int = 443
    @Volatile private var running = false
    private val lock = Any()
    private val samples = ArrayList<Int>()

    fun isRunning(): Boolean = running

    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        running = false
    }

    fun reset() {
        synchronized(lock) { samples.clear() }
    }

    private fun loop() {
        var addr: InetAddress? = null
        var resolvedFor = ""
        while (running) {
            var ms = -1
            val loopStart = SystemClock.elapsedRealtime()
            try {
                if (addr == null || resolvedFor != host) {
                    addr = InetAddress.getByName(host)
                    resolvedFor = host
                }
                val s = Socket()
                val t0 = System.nanoTime()
                s.connect(InetSocketAddress(addr, port), 1500)
                ms = ((System.nanoTime() - t0) / 1_000_000L).toInt()
                s.close()
            } catch (e: Exception) {
                addr = null
            }
            synchronized(lock) {
                samples.add(ms)
                while (samples.size > 120) samples.removeAt(0)
            }
            val spent = SystemClock.elapsedRealtime() - loopStart
            try {
                Thread.sleep(maxOf(100L, 1000L - spent))
            } catch (e: InterruptedException) {
            }
        }
    }

    fun snapshot(): List<Int> = synchronized(lock) { ArrayList(samples) }

    fun stats(): PingStats {
        val all = snapshot()
        if (all.isEmpty()) return PingStats(-1, 0, 0, 0, 0, 0, 0)
        val ok = all.filter { it >= 0 }
        val loss = (all.size - ok.size) * 100 / all.size
        if (ok.isEmpty()) return PingStats(-1, 0, 0, 0, 0, loss, all.size)
        var sum = 0
        var mn = Int.MAX_VALUE
        var mx = 0
        for (v in ok) {
            sum += v
            if (v < mn) mn = v
            if (v > mx) mx = v
        }
        var jsum = 0
        for (i in 1 until ok.size) jsum += Math.abs(ok[i] - ok[i - 1])
        val jitter = if (ok.size > 1) jsum / (ok.size - 1) else 0
        return PingStats(all.last(), sum / ok.size, mn, mx, jitter, loss, all.size)
    }
}

/** Real Wi-Fi / mobile data info. */
data class NetState(val title: String, val detail: String, val level: Int, val isWifi: Boolean, val rssi: Int, val band: String)

object NetInfo {
    fun read(ctx: Context): NetState {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return NetState("No internet", "Connect to Wi-Fi or mobile data", 0, false, 0, "")
        val caps = cm.getNetworkCapabilities(net) ?: return NetState("No internet", "", 0, false, 0, "")
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info = wm.connectionInfo
            val rssi = info.rssi
            val freq = info.frequency
            val band = if (freq >= 5925) "6 GHz" else if (freq >= 4900) "5 GHz" else if (freq > 0) "2.4 GHz" else "?"
            val level = ((rssi + 100) * 100 / 55).coerceIn(0, 100)
            val detail = "Signal $rssi dBm ($level%)\nLink speed ${info.linkSpeed} Mbps"
            return NetState("Wi-Fi  ·  $band", detail, level, true, rssi, band)
        }
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            var dbm = Int.MIN_VALUE
            if (Build.VERSION.SDK_INT >= 29) dbm = caps.signalStrength
            if (dbm == Int.MIN_VALUE || dbm == 0) {
                return NetState("Mobile data", "Signal level not given by this phone", 50, false, 0, "")
            }
            val level = ((dbm + 120) * 100 / 50).coerceIn(0, 100)
            return NetState("Mobile data", "Signal $dbm dBm ($level%)", level, false, dbm, "")
        }
        return NetState("Other network", "", 50, false, 0, "")
    }
}

/** Real download / upload speed of the whole phone, in KB/s. */
object Throughput {
    private var lastRx = 0L
    private var lastTx = 0L
    private var lastT = 0L

    fun sample(): Pair<Long, Long> {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val t = SystemClock.elapsedRealtime()
        var down = 0L
        var up = 0L
        if (lastT != 0L && t > lastT && rx >= 0 && tx >= 0) {
            val dt = t - lastT
            down = (rx - lastRx) * 1000L / dt / 1024L
            up = (tx - lastTx) * 1000L / dt / 1024L
        }
        lastRx = rx
        lastTx = tx
        lastT = t
        return Pair(maxOf(0L, down), maxOf(0L, up))
    }
}

/** Keeps Wi-Fi in low-latency mode so ping spikes are fewer. */
object WifiLockHolder {
    private var lock: WifiManager.WifiLock? = null

    fun acquire(ctx: Context): Boolean {
        return try {
            if (lock == null) {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                lock = wm.createWifiLock(mode, "LagBoost:wifi")
                lock?.setReferenceCounted(false)
            }
            if (lock?.isHeld != true) lock?.acquire()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun release() {
        try {
            if (lock?.isHeld == true) lock?.release()
        } catch (e: Exception) {
        }
    }

    fun isHeld(): Boolean = lock?.isHeld == true
}

/** Installed apps found on this phone. */
data class AppItem(val label: String, val pkg: String, val icon: Drawable?, val isGame: Boolean, val isSystem: Boolean)

object Apps {
    private val KNOWN = setOf(
        "com.tencent.ig", "com.pubg.imobile", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm",
        "com.dts.freefireth", "com.dts.freefiremax", "com.activision.callofduty.shooter",
        "com.mobile.legends", "com.supercell.clashofclans", "com.supercell.clashroyale",
        "com.tencent.tmgp.cod", "com.garena.game.codm", "com.kiloo.subwaysurf", "com.mojang.minecraftpe",
        "com.roblox.client", "com.miHoYo.GenshinImpact", "com.levelinfinite.sgameGlobal"
    )

    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val out = ArrayList<AppItem>()
        val all = pm.getInstalledApplications(0)
        for (ai in all) {
            val pkg = ai.packageName
            if (pkg == ctx.packageName) continue
            if (pm.getLaunchIntentForPackage(pkg) == null) continue
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            val game = KNOWN.contains(pkg) || ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            val name = try {
                pm.getApplicationLabel(ai).toString()
            } catch (e: Exception) {
                pkg
            }
            val icon = try {
                pm.getApplicationIcon(ai)
            } catch (e: Exception) {
                null
            }
            out.add(AppItem(name, pkg, icon, game, sys))
        }
        out.sortBy { it.label.lowercase() }
        return out
    }
}

/** Shizuku gives the app shell power: force-stop apps and read the real FPS of a game. */
object Shell {
    fun alive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun request() {
        try {
            Shizuku.requestPermission(4242)
        } catch (e: Throwable) {
        }
    }

    /** Runs a shell command with shell privileges. Returns null if it fails. */
    fun run(cmd: String): String? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val text = p.inputStream.bufferedReader().readText()
            p.waitFor()
            text
        } catch (e: Throwable) {
            null
        }
    }
}

/** Real FPS of another app (the game), read from SurfaceFlinger through Shizuku. */
object GameFps {
    private var layer: String? = null
    private var layerPkg = ""

    fun reset() {
        layer = null
    }

    fun read(pkg: String): Int? {
        if (pkg.isEmpty() || !Shell.granted()) return null
        if (layer == null || layerPkg != pkg) {
            val list = Shell.run("dumpsys SurfaceFlinger --list") ?: return null
            val cands = list.lines().map { it.trim() }.filter {
                it.contains(pkg) && !it.startsWith("Background") && !it.contains("Splash") && !it.contains("Bounds")
            }
            layer = cands.firstOrNull { it.startsWith("SurfaceView") } ?: cands.lastOrNull()
            layerPkg = pkg
            if (layer == null) return null
        }
        val out = Shell.run("dumpsys SurfaceFlinger --latency '" + layer + "'") ?: return null
        val lines = out.lines().filter { it.isNotBlank() }
        if (lines.size < 3) {
            layer = null
            return null
        }
        val times = ArrayList<Long>()
        for (i in 1 until lines.size) {
            val parts = lines[i].trim().split(Regex("\\s+"))
            if (parts.size >= 3) {
                val t = parts[1].toLongOrNull() ?: continue
                if (t > 0L && t != Long.MAX_VALUE) times.add(t)
            }
        }
        if (times.isEmpty()) {
            layer = null
            return 0
        }
        var end = 0L
        for (t in times) if (t > end) end = t
        val age = System.nanoTime() - end
        if (age in 1_500_000_000L..3_600_000_000_000L) return 0
        val from = end - 1_000_000_000L
        var n = 0
        for (t in times) if (t > from) n++
        return n
    }
}

/**
 * Reads and writes the game's settings file (Active.sav) through Shizuku.
 * It only touches that one file, a backup copy next to it, and a temporary file.
 */
object SavTools {
    private val PKG_RE = Regex("^[A-Za-z][A-Za-z0-9_.]{2,100}$")
    private val B64_RE = Regex("^[A-Za-z0-9+/=]{100,80000}$")
    private val PATH_RE = Regex("^/[A-Za-z0-9_./-]{5,300}$")
    private const val REL = "files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav"

    /** Finds the real path of Active.sav for this game. Returns null if not found. */
    private fun path(pkg: String): String? {
        if (!PKG_RE.matches(pkg)) return null
        val base = "/sdcard/Android/data/$pkg"
        val p = "$base/$REL"
        val out = Shell.run("if [ -f '$p' ]; then echo '$p'; else find '$base' -name Active.sav 2>/dev/null | head -n 1; fi")
            ?: return null
        val line = out.trim().lines().firstOrNull()?.trim() ?: return null
        return if (PATH_RE.matches(line)) line else null
    }

    /** Returns the file as base64, or a text starting with ERR: */
    fun read(pkg: String): String {
        if (!Shell.granted()) return "ERR:shizuku"
        val p = path(pkg) ?: return "ERR:notfound"
        val out = Shell.run("base64 '$p' | tr -d '\\n'")?.trim() ?: return "ERR:read"
        return if (B64_RE.matches(out)) out else "ERR:read"
    }

    /** Copies Active.sav to Active.sav.lagboost.bak. The first backup is never overwritten. */
    fun backup(pkg: String): String {
        if (!Shell.granted()) return "ERR:shizuku"
        val p = path(pkg) ?: return "ERR:notfound"
        val bak = "$p.lagboost.bak"
        val out = Shell.run("if [ -f '$bak' ]; then echo EXISTS; elif cp '$p' '$bak'; then echo OK; else echo FAIL; fi")
            ?: return "ERR:shell"
        val r = out.trim()
        return if (r == "EXISTS") "exists" else if (r == "OK") "ok" else "ERR:copy"
    }

    /** Closes the game, then writes the new file through a temp file so a broken write cannot damage the original. */
    fun write(pkg: String, b64: String): String {
        if (!Shell.granted()) return "ERR:shizuku"
        if (!B64_RE.matches(b64)) return "ERR:data"
        val p = path(pkg) ?: return "ERR:notfound"
        val tmp = "$p.lagboost.tmp"
        val cmd = "am force-stop $pkg; echo '$b64' | base64 -d > '$tmp' && [ \"\$(wc -c < '$tmp')\" -gt 1000 ] && cp '$tmp' '$p' && echo OK; rm -f '$tmp'"
        val out = Shell.run(cmd) ?: return "ERR:shell"
        return if (out.contains("OK")) "ok" else "ERR:write"
    }

    /** Puts the backup back (closes the game first). */
    fun restore(pkg: String): String {
        if (!Shell.granted()) return "ERR:shizuku"
        val p = path(pkg) ?: return "ERR:notfound"
        val bak = "$p.lagboost.bak"
        val out = Shell.run("if [ -f '$bak' ]; then am force-stop $pkg; cp '$bak' '$p' && echo OK; else echo NOBAK; fi")
            ?: return "ERR:shell"
        val r = out.trim()
        return if (r.endsWith("OK")) "ok" else if (r.contains("NOBAK")) "ERR:nobackup" else "ERR:copy"
    }
}
