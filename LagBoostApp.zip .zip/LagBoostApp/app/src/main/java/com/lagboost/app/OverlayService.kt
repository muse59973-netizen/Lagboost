@file:Suppress("DEPRECATION")

package com.lagboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * Floating counter shown over any app (the game).
 * GAME  = real FPS of the game, read through Shizuku.
 * SCREEN = how smoothly the phone screen is drawing right now (used when Shizuku is not on).
 */
class OverlayService : Service() {

    companion object {
        @Volatile var running = false

        fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

        fun start(ctx: Context) {
            val i = Intent(ctx, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }

    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var frames = 0
    private var alive = false
    @Volatile private var gameFps: Int? = null
    private var zeroCount = 0

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (alive) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!alive) return
            val screenFps = frames
            frames = 0
            val g = gameFps
            val useGame = g != null
            val fps = if (useGame) g!! else screenFps
            if (useGame && g == 0) {
                zeroCount++
                if (zeroCount >= 3) {
                    GameFps.reset()
                    zeroCount = 0
                }
            } else {
                zeroCount = 0
            }
            val ps = PingMonitor.stats()
            val ping = if (ps.last >= 0) "${ps.last} ms" else "-- ms"
            val src = if (useGame) "GAME" else "SCREEN"
            tv?.text = "$src $fps FPS\nPing $ping  Jitter ${ps.jitter}"
            tv?.setTextColor(if (fps >= 55) C.GOOD else if (fps >= 40) C.WARN else C.BAD)

            val target = Prefs.getStr(this@OverlayService, Prefs.TARGET, "")
            if (target.isNotEmpty() && Shell.granted()) {
                workerHandler?.post { gameFps = GameFps.read(target) }
            } else {
                gameFps = null
            }
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (alive) return START_STICKY
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("lagboost", "Lag Boost overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val n = Notification.Builder(this, "lagboost")
            .setContentTitle("Lag Boost FPS counter is on")
            .setContentText("Showing FPS and ping over your game")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        addOverlay()
        PingMonitor.start()
        worker = HandlerThread("fps-reader").also { it.start() }
        workerHandler = Handler(worker!!.looper)
        alive = true
        running = true
        Choreographer.getInstance().postFrameCallback(frameCb)
        handler.postDelayed(tick, 1000L)
        return START_STICKY
    }

    private fun addOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics.density
        val t = TextView(this)
        t.text = "FPS --"
        t.textSize = 13f
        t.setTextColor(C.GOOD)
        t.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        t.background = shape(0xB3050810.toInt(), 10)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (8 * d).toInt()
        lp.y = (8 * d).toInt()
        wm?.addView(t, lp)
        tv = t
    }

    override fun onDestroy() {
        alive = false
        running = false
        handler.removeCallbacksAndMessages(null)
        try {
            Choreographer.getInstance().removeFrameCallback(frameCb)
        } catch (e: Exception) {
        }
        try {
            if (tv != null) wm?.removeView(tv)
        } catch (e: Exception) {
        }
        tv = null
        worker?.quit()
        super.onDestroy()
    }
}
