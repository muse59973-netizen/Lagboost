@file:Suppress("DEPRECATION")

package com.lagboost.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

object C {
    val BG = Color.parseColor("#05070D")
    val PANEL = Color.parseColor("#0E1422")
    val LINE = Color.parseColor("#26324A")
    val FG = Color.parseColor("#E9F2FF")
    val MUTE = Color.parseColor("#8FA3C4")
    val ACCENT = Color.parseColor("#19F0FF")
    val ACCENT2 = Color.parseColor("#7A5CFF")
    val GOOD = Color.parseColor("#3DFFA2")
    val WARN = Color.parseColor("#FFB020")
    val BAD = Color.parseColor("#FF4D6D")
    val DARKTXT = Color.parseColor("#04131A")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.shape(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(fill)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.label(text: String, sizeSp: Float = 15f, color: Int = C.FG, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    return t
}

fun Context.vlp(topDp: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
    val p = if (weight > 0f) {
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
    } else {
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }
    p.topMargin = dp(topDp)
    return p
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = shape(C.PANEL, 18, C.LINE, 1)
    c.setPadding(dp(16), dp(14), dp(16), dp(14))
    return c
}

fun Context.heading(text: String): TextView {
    val t = label(text.uppercase(), 12f, C.MUTE, true)
    t.letterSpacing = 0.2f
    return t
}

fun Context.gradButton(text: String, onClick: () -> Unit): TextView {
    val b = label(text, 15f, C.DARKTXT, true)
    b.gravity = Gravity.CENTER
    b.letterSpacing = 0.08f
    b.setPadding(dp(16), dp(13), dp(16), dp(13))
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.ACCENT, C.ACCENT2))
    g.cornerRadius = dp(14).toFloat()
    b.background = g
    b.setOnClickListener { onClick() }
    return b
}

fun Context.ghostButton(text: String, onClick: () -> Unit): TextView {
    val b = label(text, 14f, C.FG, true)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(14), dp(11), dp(14), dp(11))
    b.background = shape(C.PANEL, 12, C.ACCENT, 1)
    b.setOnClickListener { onClick() }
    return b
}

/** Live ping graph. Failed pings (-1) are drawn as red marks at the bottom. */
class GraphView(context: Context) : View(context) {
    var data: List<Int> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C.ACCENT
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val gridPaint = Paint().apply {
        color = C.LINE
        strokeWidth = 2f
    }
    private val lossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = C.BAD }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = C.MUTE
        textSize = 28f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawLine(0f, h * 0.25f, w, h * 0.25f, gridPaint)
        canvas.drawLine(0f, h * 0.75f, w, h * 0.75f, gridPaint)
        if (data.size < 2) return
        var mx = 100
        for (v in data) if (v > mx) mx = v
        canvas.drawText("$mx ms", 6f, 28f, textPaint)
        val step = w / 119f
        val path = Path()
        var started = false
        for (i in data.indices) {
            val v = data[i]
            val x = w - (data.size - 1 - i) * step
            if (v < 0) {
                canvas.drawCircle(x, h - 10f, 6f, lossPaint)
                started = false
                continue
            }
            val y = h - 8f - (v.toFloat() / mx) * (h - 24f)
            if (!started) {
                path.moveTo(x, y)
                started = true
            } else {
                path.lineTo(x, y)
            }
        }
        canvas.drawPath(path, linePaint)
    }
}
