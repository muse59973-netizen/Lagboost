package com.lagboost.app;

interface IFileService {
    void destroy() = 16777114;
    byte[] read(String path) = 1;
    String write(String path, in byte[] data) = 2;
    String copy(String from, String to) = 3;
    boolean exists(String path) = 4;
    void forceStop(String pkg) = 5;
}
