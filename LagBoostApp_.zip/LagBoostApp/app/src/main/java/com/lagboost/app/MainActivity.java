package com.lagboost.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import rikka.shizuku.Shizuku;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.local";
    private static final int REQ_FILE = 101;
    private static final Set<String> KNOWN_GAMES = new HashSet<String>(Arrays.asList(
            "com.tencent.ig", "com.tencent.iglite", "com.pubg.krmobile", "com.pubg.imobile",
            "com.vng.pubgmobile", "com.rekoo.pubgm", "com.dts.freefireth", "com.dts.freefiremax",
            "com.activision.callofduty.shooter"));

    private WebView web;
    private ValueCallback<Uri[]> filePathCb;

    private Shizuku.UserServiceArgs usArgs;
    private volatile IFileService fs;
    private volatile boolean binding;
    private final ServiceConnection conn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            fs = IFileService.Stub.asInterface(binder);
            binding = false;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            fs = null;
            binding = false;
        }
    };

    private String shizState() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) return "off";
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return "running";
            if (fs == null && !binding) {
                binding = true;
                runOnUiThread(() -> {
                    try {
                        Shizuku.bindUserService(usArgs, conn);
                    } catch (Throwable t) {
                        binding = false;
                    }
                });
            }
            return "granted";
        } catch (Throwable t) {
            return "off";
        }
    }

    private boolean ensureFs() {
        if (!"granted".equals(shizState())) return false;
        for (int i = 0; i < 40 && fs == null; i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException ignored) {
            }
        }
        return fs != null;
    }

    private String savPath(String pkg) {
        return "/storage/emulated/0/Android/data/" + pkg
                + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/Active.sav";
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usArgs = new Shizuku.UserServiceArgs(new ComponentName(getPackageName(), FileService.class.getName()))
                .daemon(false).processNameSuffix("fs").version(1);
        web = new WebView(this);
        web.setBackgroundColor(0xFF05070D);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u != null && HOST.equals(u.getHost())) {
                    try {
                        String p = u.getPath();
                        if (p == null || p.equals("/") || p.isEmpty()) {
                            p = "/index.html";
                        }
                        InputStream in = getAssets().open(p.substring(1));
                        String mime = p.endsWith(".html") ? "text/html" : "application/octet-stream";
                        return new WebResourceResponse(mime, "utf-8", in);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u == null) return true;
                if (HOST.equals(u.getHost()) || "blob".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (filePathCb != null) {
                    filePathCb.onReceiveValue(null);
                }
                filePathCb = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose file"), REQ_FILE);
                } catch (Exception e) {
                    filePathCb = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url != null && url.startsWith("blob:")) {
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType).replace("'", "");
                String js = "(function(){var x=new XMLHttpRequest();x.open('GET','" + url
                        + "',true);x.responseType='blob';x.onload=function(){var r=new FileReader();"
                        + "r.onloadend=function(){Android.saveDataUrl('" + name + "',r.result)};"
                        + "r.readAsDataURL(x.response)};x.send()})()";
                web.evaluateJavascript(js, null);
            }
        });

        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && filePathCb != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCb.onReceiveValue(result);
            filePathCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private String saveToDownloads(String name, byte[] data, String mime) {
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, name);
            v.put(MediaStore.Downloads.MIME_TYPE, mime);
            v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LagBoost");
            Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) return "ERR:insert";
            OutputStream o = getContentResolver().openOutputStream(u);
            if (o == null) return "ERR:open";
            o.write(data);
            o.close();
            return "ok";
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }

    private boolean hasOverlayPermission() {
        return Settings.canDrawOverlays(this);
    }

    private void askOverlayPermission() {
        runOnUiThread(() -> {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {
            }
        });
    }

    private boolean isGame(ApplicationInfo ai, String pkg) {
        if (Build.VERSION.SDK_INT >= 26 && ai != null && ai.category == ApplicationInfo.CATEGORY_GAME) {
            return true;
        }
        return KNOWN_GAMES.contains(pkg);
    }

    private String appList(boolean gamesOnly) {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        ArrayList<String[]> out = new ArrayList<String[]>();
        HashSet<String> seen = new HashSet<String>();
        for (ResolveInfo r : list) {
            String p = r.activityInfo.packageName;
            if (p.equals(getPackageName()) || !seen.add(p)) continue;
            if (gamesOnly && !isGame(r.activityInfo.applicationInfo, p)) continue;
            out.add(new String[]{p, String.valueOf(r.loadLabel(pm))});
        }
        Collections.sort(out, (a, b) -> a[1].compareToIgnoreCase(b[1]));
        JSONArray arr = new JSONArray();
        for (String[] o : out) {
            JSONObject j = new JSONObject();
            try {
                j.put("pkg", o[0]);
                j.put("name", o[1]);
            } catch (JSONException ignored) {
            }
            arr.put(j);
        }
        return arr.toString();
    }

    private int killList(String json) {
        int n = 0;
        try {
            JSONArray a = new JSONArray(json);
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            for (int k = 0; k < a.length(); k++) {
                String p = a.optString(k, "");
                if (p.isEmpty() || p.equals(getPackageName())) continue;
                am.killBackgroundProcesses(p);
                n++;
            }
        } catch (Exception ignored) {
        }
        return n;
    }

    /** Methods called from index.html as window.Android.xxx */
    public class Bridge {

        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public String ramInfo() {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long free = mi.availMem / 1048576L;
            long total = Math.max(1L, mi.totalMem / 1048576L);
            return "{\"free\":" + free + ",\"total\":" + total + "}";
        }

        @JavascriptInterface
        public int gameFps() {
            return -1;
        }

        @JavascriptInterface
        public String getApps() {
            return appList(false);
        }

        @JavascriptInterface
        public String getGames() {
            return appList(true);
        }

        @JavascriptInterface
        public int kill(String json) {
            return killList(json);
        }

        @JavascriptInterface
        public String play(String pkg, String killJson, boolean fps, boolean boost) {
            if (fps && !hasOverlayPermission()) {
                askOverlayPermission();
                return "need_overlay";
            }
            int n = boost ? killList(killJson) : 0;
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch == null) return "ERR:notinstalled";
            if (fps) {
                startService(new Intent(MainActivity.this, OverlayService.class));
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                startActivity(launch);
            } catch (Exception e) {
                return "ERR:launch";
            }
            return "ok:" + n;
        }

        @JavascriptInterface
        public String overlay(boolean on) {
            if (on) {
                if (!hasOverlayPermission()) {
                    askOverlayPermission();
                    return "need_overlay";
                }
                startService(new Intent(MainActivity.this, OverlayService.class));
            } else {
                stopService(new Intent(MainActivity.this, OverlayService.class));
            }
            return "ok";
        }

        @JavascriptInterface
        public String tint(boolean on, double w, double dim) {
            Intent i = new Intent(MainActivity.this, TintService.class);
            if (on) {
                if (!hasOverlayPermission()) {
                    askOverlayPermission();
                    return "need_overlay";
                }
                i.putExtra("w", (float) w);
                i.putExtra("dim", (float) dim);
                startService(i);
            } else {
                stopService(i);
            }
            return "ok";
        }

        @JavascriptInterface
        public void disconnect() {
            stopService(new Intent(MainActivity.this, OverlayService.class));
            stopService(new Intent(MainActivity.this, TintService.class));
        }

        @JavascriptInterface
        public void keepAwake(final boolean on) {
            runOnUiThread(() -> {
                if (on) {
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }

        @JavascriptInterface
        public String shizuku() {
            return shizState();
        }

        @JavascriptInterface
        public void shizukuRequest() {
            runOnUiThread(() -> {
                try {
                    if (Shizuku.pingBinder() && !Shizuku.isPreV11()) {
                        Shizuku.requestPermission(1001);
                    }
                } catch (Throwable ignored) {
                }
            });
        }

        @JavascriptInterface
        public String savRead(String pkg) {
            if (!ensureFs()) return "ERR:shizuku";
            try {
                String p = savPath(pkg);
                if (!fs.exists(p)) return "ERR:notfound";
                byte[] d = fs.read(p);
                if (d == null) return "ERR:read";
                return Base64.encodeToString(d, Base64.NO_WRAP);
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String savBackup(String pkg) {
            if (!ensureFs()) return "ERR:shizuku";
            try {
                String p = savPath(pkg);
                if (!fs.exists(p)) return "ERR:notfound";
                String bk = p + ".lagboost.bak";
                if (fs.exists(bk)) return "exists";
                String r = fs.copy(p, bk);
                return r;
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String savWrite(String pkg, String b64) {
            if (!ensureFs()) return "ERR:shizuku";
            try {
                String p = savPath(pkg);
                if (!fs.exists(p)) return "ERR:notfound";
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                fs.forceStop(pkg);
                return fs.write(p, data);
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String savRestore(String pkg) {
            if (!ensureFs()) return "ERR:shizuku";
            try {
                String p = savPath(pkg);
                String bk = p + ".lagboost.bak";
                if (!fs.exists(bk)) return "ERR:nobackup";
                fs.forceStop(pkg);
                return fs.copy(bk, p);
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        /** Files bundled inside the APK (assets/saves). */
        @JavascriptInterface
        public String listSaves() {
            JSONArray arr = new JSONArray();
            try {
                String[] names = getAssets().list("saves");
                if (names != null) {
                    Arrays.sort(names);
                    for (String n : names) arr.put(n);
                }
            } catch (IOException ignored) {
            }
            return arr.toString();
        }

        @JavascriptInterface
        public String exportSave(String name) {
            if (name == null || name.contains("/") || name.contains("..")) return "ERR:name";
            try {
                InputStream in = getAssets().open("saves/" + name);
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
                in.close();
                return saveToDownloads(name, bo.toByteArray(), "application/octet-stream");
            } catch (IOException e) {
                return "ERR:read";
            }
        }

        /** Used for blob downloads (e.g. patched Active.sav) from the web UI. */
        @JavascriptInterface
        public void saveDataUrl(String name, String dataUrl) {
            try {
                int c = dataUrl.indexOf(',');
                byte[] data = Base64.decode(dataUrl.substring(c + 1), Base64.DEFAULT);
                String r = saveToDownloads(name, data, "application/octet-stream");
                toast("ok".equals(r) ? "Saved in Downloads/LagBoost: " + name : "Could not save (" + r + ")");
            } catch (Exception e) {
                toast("Could not save file");
            }
        }
    }
}
