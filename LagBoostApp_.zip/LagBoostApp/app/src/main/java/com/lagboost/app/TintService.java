package com.lagboost.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

/** Full-screen colour tint and dim layer (touch-through). */
public class TintService extends Service {

    private WindowManager wm;
    private FrameLayout root;
    private View dimV;
    private View warmV;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        float w = intent != null ? intent.getFloatExtra("w", 0f) : 0f;
        float dim = intent != null ? intent.getFloatExtra("dim", 0f) : 0f;

        if (root == null && Settings.canDrawOverlays(this)) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            root = new FrameLayout(this);
            warmV = new View(this);
            dimV = new View(this);
            root.addView(warmV, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            root.addView(dimV, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            try {
                wm.addView(root, lp);
            } catch (Exception e) {
                root = null;
            }
        }

        if (root != null) {
            float d = Math.max(0f, Math.min(70f, dim));
            dimV.setBackgroundColor(Color.argb((int) (d / 100f * 255f), 0, 0, 0));
            float aw = Math.min(50f, Math.abs(w));
            int warmAlpha = (int) (aw / 50f * 60f);
            if (w > 0) {
                warmV.setBackgroundColor(Color.argb(warmAlpha, 255, 140, 0));
            } else {
                warmV.setBackgroundColor(Color.argb(warmAlpha, 0, 120, 255));
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wm != null && root != null) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {
            }
        }
        root = null;
        super.onDestroy();
    }
}
