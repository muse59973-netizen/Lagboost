package com.lagboost.app;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** Runs inside the Shizuku process (shell user). Touches only the paths the app asks for. */
public class FileService extends IFileService.Stub {

    public FileService() {
    }

    @Override
    public void destroy() {
        System.exit(0);
    }

    @Override
    public byte[] read(String path) {
        try {
            FileInputStream in = new FileInputStream(path);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) {
                bo.write(buf, 0, r);
            }
            in.close();
            return bo.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public String write(String path, byte[] data) {
        try {
            FileOutputStream o = new FileOutputStream(path);
            o.write(data);
            o.flush();
            o.close();
            return "ok";
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }

    @Override
    public String copy(String from, String to) {
        byte[] d = read(from);
        if (d == null) return "ERR:notfound";
        String r = write(to, d);
        return r;
    }

    @Override
    public boolean exists(String path) {
        return new File(path).exists();
    }

    @Override
    public void forceStop(String pkg) {
        try {
            Runtime.getRuntime().exec(new String[]{"am", "force-stop", pkg}).waitFor();
        } catch (Exception ignored) {
        }
    }
}
