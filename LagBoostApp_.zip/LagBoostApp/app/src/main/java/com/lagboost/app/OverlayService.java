package com.lagboost.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;

/** Small floating label showing the display refresh rate while gaming. */
public class OverlayService extends Service {

    private WindowManager wm;
    private TextView tv;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (tv == null && Settings.canDrawOverlays(this)) {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            tv = new TextView(this);
            float hz = wm.getDefaultDisplay().getRefreshRate();
            tv.setText("Lag Boost | display " + Math.round(hz) + " Hz");
            tv.setTextColor(0xFF00E5FF);
            tv.setTextSize(12f);
            tv.setBackgroundColor(0x99000000);
            tv.setPadding(16, 8, 16, 8);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 20;
            lp.y = 40;
            try {
                wm.addView(tv, lp);
            } catch (Exception e) {
                tv = null;
            }
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wm != null && tv != null) {
            try {
                wm.removeView(tv);
            } catch (Exception ignored) {
            }
        }
        tv = null;
        super.onDestroy();
    }
}
